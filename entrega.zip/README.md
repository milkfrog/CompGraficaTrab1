# CompGraficaTrab1

sudo apt install python3-pip

instalar o tkinter no linux:
sudo apt-get install python3-tk

pip3 install numpy

sudo apt-get install python3-sympy
from App import *

app = App()